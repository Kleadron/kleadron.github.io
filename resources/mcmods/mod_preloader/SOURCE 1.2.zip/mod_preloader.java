
/** 
 * Copyright (c) Kleadron, 2020
 * http://kleadron.github.io/mod_preloader.html
 * 
 * Texture Pre-Loader is distributed under the terms of the Minecraft Mod Public 
 * License 1.0, or MMPL. Please check the contents of the license located in
 * http://www.mod-buildcraft.com/MMPL-1.0.txt
 */

package net.minecraft.src;

import java.io.File;
import java.io.RandomAccessFile;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.src.forge.ITextureLoadHandler;
import net.minecraft.src.forge.MinecraftForgeClient;

public class mod_preloader extends BaseMod implements ITextureLoadHandler {

	List<String> capturedTextures = new ArrayList<String>();
	
	boolean capturing = false;
	
	@MLProp(info = "Set to false to stop texture loading from spamming the log.")
	public static boolean logLoadedTextures = true;
	
	@MLProp(info = "Set to false to stop \"Found new texture\" messages from appearing in the log.")
	public static boolean announceNewTexture = true;
	
	public mod_preloader() {
		Log("Kleadron Software " + getName() + ", Version " + getVersion(), false);
	}
	
	RandomAccessFile capturedTextureFile;
	
	void Log(String toLog) {
		Log(toLog, true);
	}
	
	void Log(String toLog, boolean withName) {
		if (withName)
			System.out.println( getName() + ": " + toLog);
		else
			System.out.println(toLog);
	}
	
	void InitializePreload() {
		try {
			File texNameFile = new File("preload_textures.txt");
			if (texNameFile.createNewFile()) {
				Log("Created new texture list file.");
			} else {
				Log("Texture list file exists.");
			}
			capturedTextureFile = new RandomAccessFile(texNameFile, "rw");
			while(capturedTextureFile.getFilePointer() < capturedTextureFile.length()) {
				String line = capturedTextureFile.readLine();
				line = line.trim();
				if (!line.equals(""))
					capturedTextures.add(line);
			}
			
		} catch(Exception e) {
			Log("Error with preload text file.");
			System.out.println(e);
		}
	}
	
	@Override
	public String getName() {
		return "Texture Pre-Loader";
	}
	
	@Override
	public String getVersion() {
		return "1.2";
	}

	@Override
	public void load() {
		Log("Hi! :]");
		InitializePreload();
		MinecraftForgeClient.registerTextureLoadHandler(this);
		if (capturedTextureFile != null) {
			Log("Waiting for initial mod load completion.");
		}
	}
	
	@Override
	public void modsLoaded() {
		if (capturedTextureFile != null) {
			Log("Loading the god damned textures.");
			Instant loadStart = Instant.now();
			for(String tex: capturedTextures) {
				if (logLoadedTextures)
					Log(tex, false);
				MinecraftForgeClient.preloadTexture(tex);
			}
			Instant loadEnd = Instant.now();
			
			capturing = true;
			
			Log("Done! Took " + Duration.between(loadStart, loadEnd).toMillis() + " milliseconds to load. Enabling texture capturing.");
		
		} else {
			Log("Unabled to load textures. Texture file is invalid.");
		}
		
	}

	@Override
	public void onTextureLoad(String textureName, int textureID) {
		if (capturing) {
			if (!capturedTextures.contains(textureName)) {
				capturedTextures.add(textureName);
				try {
					capturedTextureFile.writeBytes(textureName + System.lineSeparator());
				} catch (Exception e) {
					Log("Failed to write " + textureName + " to texture list");
				}
				if (announceNewTexture)
					Log("Found new texture: " + textureName);
			}
		}
	}
}
